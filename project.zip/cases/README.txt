Put your custom test case .txt files in this directory.
